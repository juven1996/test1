Juven Ardine Hernanto Putra, A00931159, 1C, 10/04/2014

This assignment is 100% complete.


------------------------
Question one (Change) status:

Complete
Cant get rid of checkstyle error of too much method
------------------------
Question two (SecondsConvert) status:

Complete

------------------------
Question three (Arithemtic) status:

Complete

------------------------
Question four (Cube) status:

Complete

------------------------
Question five (Pie Chart) status:

Complete
Left some checkstyle errors as it is clear
